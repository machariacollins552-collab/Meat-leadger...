# PorkPilot

Smart Butchery. Better Profits.

A phone-first app for managing a pork butchery in Kenya. It runs inside an Android WebView, the UI is bundled in the app, and it works offline.

## Features

- Sales by weight (cash, M-Pesa with transaction code, credit, other) with copyable receipts
- Stock with weighted-average cost, stock in, and write-offs
- Profit per sale and per item, expenses, and net profit reports
- Customers, credit balances and payments, with reminder messages
- M-Pesa record to match against your statement
- Sales CSV export

## Build the APK with GitHub Actions

1. Create a GitHub repository and upload the contents of this folder to its root, keeping the folder structure. Check that `.github/workflows/build-apk.yml` is there.
2. Commit to the `main` branch.
3. Open the **Actions** tab and run **Build PorkPilot APK** if it has not started on its own.
4. When it finishes, download `PorkPilot-debug-apk` from the run's **Artifacts**, unzip it, and install `app-debug.apk` on your phone.

## Notes

- Records are saved on the phone only. Back up with Export sales (CSV) in More.
- M-Pesa is recorded by hand. There is no live STK Push.
- The first build is a debug APK, not a signed Play Store release.
